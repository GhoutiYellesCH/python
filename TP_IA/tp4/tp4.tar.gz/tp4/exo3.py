# import cp_model library
from ortools.sat.python import cp_model

# création d'un modèle.
model = cp_model.CpModel()

# Declare variables for ages
H = model.NewIntVar(11, 24, "H")
K = model.NewIntVar(11, 24, "K")
L = model.NewIntVar(11, 24, "L")
O = model.NewIntVar(11, 24, "O")
Y = model.NewIntVar(11, 24, "Y")

# Add constraints
model.AddAllDifferent([H, K, O, Y])
model.Add(H == K - 8)
model.Add(H != Y)
model.Add(Y < L)
model.Add(L == H)
model.Add(O == H - 10)
model.AddModuloEquality(1, H - O, 2)

# Create the solver and solve
solver = cp_model.CpSolver()
status = solver.Solve(model)

# Print the solution
if status == cp_model.OPTIMAL or status == cp_model.FEASIBLE:
    print(
        f"H = {solver.Value(H)}, K = {solver.Value(K)}, L = {solver.Value(L)}, O = {solver.Value(O)}, Y = {solver.Value(Y)}"
    )
else:
    print("No solution found.")
