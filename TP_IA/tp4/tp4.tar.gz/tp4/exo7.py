# import cp_model library
from ortools.sat.python import cp_model

# création d'un modèle.
model = cp_model.CpModel()

# Define the Sudoku puzzle
puzzle = [
    [0, 3, 0, 4, 0, 5, 0, 7, 0],
    [6, 2, 0, 0, 8, 0, 4, 0, 0],
    [7, 0, 0, 0, 0, 1, 0, 0, 9],
    [2, 0, 6, 0, 0, 3, 8, 0, 0],
    [0, 0, 0, 0, 0, 0, 2, 0, 3],
    [0, 1, 3, 6, 0, 0, 9, 5, 0],
    [0, 0, 8, 0, 4, 7, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 6],
    [0, 0, 9, 0, 5, 0, 3, 8, 2],
]

# Create variables for the Sudoku grid
cells = {}
for i in range(9):
    for j in range(9):
        if puzzle[i][j] == 0:
            cells[(i, j)] = model.NewIntVar(1, 9, f"cell_{i}_{j}")
        else:
            cells[(i, j)] = model.NewIntVar(puzzle[i][j], puzzle[i][j], f"cell_{i}_{j}")

# Add constraints for rows, columns, and 3x3 boxes
for i in range(9):
    model.AddAllDifferent([cells[(i, j)] for j in range(9)])  # Rows
    model.AddAllDifferent([cells[(j, i)] for j in range(9)])  # Columns

for i in range(3):
    for j in range(3):
        model.AddAllDifferent(
            [cells[(3 * i + di, 3 * j + dj)] for di in range(3) for dj in range(3)]
        )  # 3x3 boxes

# Create the solver and solve
solver = cp_model.CpSolver()
status = solver.Solve(model)

# Print the solution
if status == cp_model.OPTIMAL or status == cp_model.FEASIBLE:
    for i in range(9):
        row = [solver.Value(cells[(i, j)]) for j in range(9)]
        print(row)
else:
    print("No solution found.")
