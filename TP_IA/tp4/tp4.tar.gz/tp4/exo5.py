from ortools.sat.python import cp_model


def magic_square(n):
    model = cp_model.CpModel()

    # Create variables for the magic square
    square = [
        [model.NewIntVar(1, n * n, f"square_{i}_{j}") for j in range(n)]
        for i in range(n)
    ]

    # Add all different constraints
    model.AddAllDifferent([square[i][j] for i in range(n) for j in range(n)])

    # Magic constant
    magic_sum = n * (n * n + 1) // 2

    # Add row constraints
    for i in range(n):
        model.Add(sum(square[i][j] for j in range(n)) == magic_sum)

    # Add column constraints
    for j in range(n):
        model.Add(sum(square[i][j] for i in range(n)) == magic_sum)

    # Add diagonal constraints
    model.Add(sum(square[i][i] for i in range(n)) == magic_sum)  # Main diagonal
    model.Add(
        sum(square[i][n - 1 - i] for i in range(n)) == magic_sum
    )  # Secondary diagonal

    # Solve the model
    solver = cp_model.CpSolver()
    status = solver.Solve(model)

    if status == cp_model.OPTIMAL or status == cp_model.FEASIBLE:
        print(f"Magic Square of order {n}:")
        for i in range(n):
            row = [solver.Value(square[i][j]) for j in range(n)]
            print(row)
        print()
    else:
        print(f"No solution found for magic square of order {n}.")


# Run the magic square solver for n = 3, 6, and 10
for order in [3, 6, 10]:
    magic_square(order)
