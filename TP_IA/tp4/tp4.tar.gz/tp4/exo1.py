# import cp_model library
from ortools.sat.python import cp_model

# création d'un modèle.
model = cp_model.CpModel()

# Declare variables
x = model.NewIntVar(0, 10, "x")
y = model.NewIntVarFromDomain(cp_model.Domain.FromValues([2, 3, 8]), "y")
z = model.NewIntVar(1, 8, "z")

# Add constraints
model.Add(x + y == 8)
model.Add(x > y)
model.Add(z + y <= x)

# Create the solver and solve
solver = cp_model.CpSolver()
status = solver.Solve(model)

# Print the solution
if status == cp_model.OPTIMAL or status == cp_model.FEASIBLE:
    print(f"x = {solver.Value(x)}, y = {solver.Value(y)}, z = {solver.Value(z)}")
else:
    print("No solution found.")
