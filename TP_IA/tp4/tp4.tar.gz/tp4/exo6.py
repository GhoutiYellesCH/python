# import cp_model library
from ortools.sat.python import cp_model

# création d'un modèle.
model = cp_model.CpModel()

# Create variables
queens = [model.NewIntVar(0, 7, f"queen_{i}") for i in range(8)]

# Add constraints
model.AddAllDifferent(queens)  # No two queens in the same row
model.AddAllDifferent(
    [queens[i] + i for i in range(8)]
)  # No two queens in the same diagonal \
model.AddAllDifferent(
    [queens[i] - i for i in range(8)]
)  # No two queens in the same diagonal

# Create the solver and solve
solver = cp_model.CpSolver()
status = solver.Solve(model)

# Print the solution
if status == cp_model.OPTIMAL or status == cp_model.FEASIBLE:
    for i in range(8):
        print(f"Queen {i} is placed at row {solver.Value(queens[i])}")
else:
    print("No solution found.")
