from ortools.sat.python import cp_model


def zebra_puzzle():
    model = cp_model.CpModel()

    # Variables representing the houses
    num_houses = 5
    colors = ["red", "green", "white", "yellow", "blue"]
    nationalities = ["English", "Ukrainian", "Norwegian", "Spanish", "Japanese"]
    drinks = ["coffee", "tea", "milk", "orange juice", "water"]
    pets = ["dog", "snails", "fox", "horse", "zebra"]
    professions = ["sculptor", "diplomat", "doctor", "violinist", "acrobat"]

    # Create variables for each attribute
    color_vars = [
        model.NewIntVar(0, num_houses - 1, f"color_{i}") for i in range(num_houses)
    ]
    nationality_vars = [
        model.NewIntVar(0, num_houses - 1, f"nationality_{i}")
        for i in range(num_houses)
    ]
    drink_vars = [
        model.NewIntVar(0, num_houses - 1, f"drink_{i}") for i in range(num_houses)
    ]
    pet_vars = [
        model.NewIntVar(0, num_houses - 1, f"pet_{i}") for i in range(num_houses)
    ]
    profession_vars = [
        model.NewIntVar(0, num_houses - 1, f"profession_{i}") for i in range(num_houses)
    ]

    # Add all different constraints
    model.AddAllDifferent(color_vars)
    model.AddAllDifferent(nationality_vars)
    model.AddAllDifferent(drink_vars)
    model.AddAllDifferent(pet_vars)
    model.AddAllDifferent(profession_vars)

    # Constraints based on the clues
    model.Add(nationality_vars[0] == 2)  # Norwegian lives in the first house
    model.Add(drink_vars[2] == 2)  # Milk is drunk in the middle house
    model.Add(
        nationality_vars[0] == color_vars[4]
    )  # Norwegian lives next to the blue house
    model.Add(nationality_vars[1] == 0)  # Englishman lives in the red house
    model.Add(drink_vars[3] == 0)  # Coffee is drunk in the green house
    model.Add(
        color_vars[3] == color_vars[2] + 1
    )  # Green house is right of the white house
    model.Add(pet_vars[1] == 0)  # Spaniard owns the dog
    model.Add(profession_vars[3] == 1)  # Sculptor owns snails
    model.Add(nationality_vars[4] == 1)  # Ukrainian drinks tea
    model.Add(
        nationality_vars[3] == pet_vars[2]
    )  # Diplomat lives next to the house with the fox
    model.Add(pet_vars[4] == 3)  # Violinist drinks orange juice
    model.Add(pet_vars[3] == 1)  # Horse lives next to the house of the diplomat
    model.Add(color_vars[2] == 3)  # Green house is to the right of the white house

    # Solve the model
    solver = cp_model.CpSolver()
    status = solver.Solve(model)

    if status == cp_model.OPTIMAL or status == cp_model.FEASIBLE:
        for i in range(num_houses):
            print(f"House {i + 1}:")
            print(f"  Color: {colors[solver.Value(color_vars[i])]}")
            print(f"  Nationality: {nationalities[solver.Value(nationality_vars[i])]}")
            print(f"  Drink: {drinks[solver.Value(drink_vars[i])]}")
            print(f"  Pet: {pets[solver.Value(pet_vars[i])]}")
            print(f"  Profession: {professions[solver.Value(profession_vars[i])]}\n")

        # Find who drinks water and who owns the zebra
        for i in range(num_houses):
            if solver.Value(drink_vars[i]) == drinks.index("water"):
                print(
                    f"The person who drinks water is: {nationalities[solver.Value(nationality_vars[i])]}"
                )
            if solver.Value(pet_vars[i]) == pets.index("zebra"):
                print(
                    f"The person who owns the zebra is: {nationalities[solver.Value(nationality_vars[i])]}"
                )

    else:
        print("No solution found.")


# Run the zebra puzzle solver
zebra_puzzle()
