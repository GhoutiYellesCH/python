# import cp_model library
from ortools.sat.python import cp_model

# création d'un modèle.
model = cp_model.CpModel()


# Create variables for each letter
S = model.NewIntVar(0, 9, "S")
E = model.NewIntVar(0, 9, "E")
N = model.NewIntVar(0, 9, "N")
D = model.NewIntVar(0, 9, "D")
M = model.NewIntVar(0, 9, "M")
O = model.NewIntVar(0, 9, "O")
R = model.NewIntVar(0, 9, "R")
Y = model.NewIntVar(0, 9, "Y")

# Add constraints
model.Add(S != 0)
model.Add(M != 0)
model.AddAllDifferent([S, E, N, D, M, O, R, Y])
model.Add(
    1000 * S + 100 * E + 10 * N + D + 1000 * M + 100 * O + 10 * R + E
    == 10000 * M + 1000 * O + 100 * N + 10 * E + Y
)

# Create the solver and solve
solver = cp_model.CpSolver()
status = solver.Solve(model)

# Print the solution
if status == cp_model.OPTIMAL or status == cp_model.FEASIBLE:
    print(
        f"S = {solver.Value(S)}, E = {solver.Value(E)}, N = {solver.Value(N)}, D = {solver.Value(D)}"
    )
    print(
        f"M = {solver.Value(M)}, O = {solver.Value(O)}, R = {solver.Value(R)}, Y = {solver.Value(Y)}"
    )
else:
    print("No solution found.")
